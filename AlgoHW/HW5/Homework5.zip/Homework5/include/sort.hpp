#include <iostream>
#include <string>
#include <vector> 

extern std::string sortAlgName;

template<class T>
void sort(std::vector<T> &array, int l, int r);
